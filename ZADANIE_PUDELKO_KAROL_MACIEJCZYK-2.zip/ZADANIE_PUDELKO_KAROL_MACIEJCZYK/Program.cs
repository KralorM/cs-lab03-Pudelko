﻿using System;
using PudelkoLibrary;
using static PudelkoLibrary.Pudelko;

namespace PudelkoApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Pudelko p1 = new Pudelko(3, 1.43, 7.85, Pudelko.Unitofmeasure.meter);
            Pudelko p2 = new Pudelko(3, 1.45, 8.85, Pudelko.Unitofmeasure.milimetr);
            Pudelko p3 = new Pudelko(5, 1.43, 7.85, Pudelko.Unitofmeasure.centimeter);
            Pudelko p4 = new Pudelko(5, 1.43, 7.85);
            Pudelko p5 = new Pudelko(1,3,5, Pudelko.Unitofmeasure.meter);
            Pudelko p6 = new Pudelko(5, 6, 7, Pudelko.Unitofmeasure.meter);
            
            List<Pudelko> Pudelka = new List<Pudelko>() {p1,p2,p3,p4};
            
            if (p1 != null)
            {
                Console.WriteLine("\nSort");
                Pudelka
                    .OrderBy(p1 => p1.Objętość)
                    .ThenBy(p1 => p1.Pole)
                    .ThenBy(p1 => p1.A + p1.B + p1.C)
                    .ToList();

            }

            foreach (var Pudelko in Pudelka)
                Console.WriteLine(Pudelko.ToString());

            //Równość Pudełek
            Console.WriteLine(p1.Equals(p2));

            //Parse & ToString
            Console.WriteLine(Pudelko.Parse("2.5 cm x 9 cm x 1 cm").ToString());

            //Pole i Objętość
            Console.WriteLine(p5.Pole);
            Console.WriteLine(p5.Objętość);

            //Konwersje
            Console.WriteLine("Operacje konwersji");
            double[] dimensions = (double[])p5;


            Console.WriteLine("Konwersja jawna");
            foreach (var d in dimensions)         
                Console.Write($"{d}, ");

        }

    }

}